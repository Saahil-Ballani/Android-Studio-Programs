package com.example.lab11;

import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class FragmentSecond extends Fragment{

    private EditText ed_name;
    private EditText ed_email;
    private EditText ed_phone;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fargment_second,container,false);
        ed_name = view.findViewById(R.id.txt_name);
        ed_email = view.findViewById(R.id.txt_email);
        ed_phone = view.findViewById(R.id.txt_phone);

        return  view;
    }
    public void addContact(View view) {

        String name = ed_name.getText().toString();
        String email = ed_email.getText().toString();
        String phone = ed_phone.getText().toString();
        Intent intent = new Intent(Intent.ACTION_INSERT);
        intent.setType(ContactsContract.Contacts.CONTENT_TYPE);
        intent.putExtra(ContactsContract.Intents.Insert.NAME, name);
        intent.putExtra(ContactsContract.Intents.Insert.EMAIL, email);
        intent.putExtra(ContactsContract.Intents.Insert.PHONE, phone);

            startActivity(intent);

    }
    }
